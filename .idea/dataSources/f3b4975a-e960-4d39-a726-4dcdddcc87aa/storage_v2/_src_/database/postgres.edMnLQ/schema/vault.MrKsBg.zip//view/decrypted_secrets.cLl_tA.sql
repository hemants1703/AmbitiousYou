create view decrypted_secrets
            (id, name, description, secret, decrypted_secret, key_id, nonce, created_at, updated_at) as
SELECT id,
       name,
       description,
       secret,
       convert_from(vault._crypto_aead_det_decrypt(message => decode(secret, 'base64'::text),
                                                   additional => convert_to(id::text, 'utf8'::name),
                                                   key_id => 0::bigint, context => '\x7067736f6469756d'::bytea,
                                                   nonce => nonce), 'utf8'::name) AS decrypted_secret,
       key_id,
       nonce,
       created_at,
       updated_at
FROM vault.secrets s;

alter table decrypted_secrets
    owner to supabase_admin;

grant delete, references, select, truncate on decrypted_secrets to postgres with grant option;

grant delete, select on decrypted_secrets to service_role;

