create function get_common_prefix(p_key text, p_prefix text, p_delimiter text) returns text
    immutable
    language sql
as
$$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;

alter function get_common_prefix(text, text, text) owner to supabase_storage_admin;

