create function foldername(name text) returns text[]
    immutable
    language plpgsql
as
$$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;

alter function foldername(text) owner to supabase_storage_admin;

