create function filename(name text) returns text
    immutable
    language plpgsql
as
$$
DECLARE
    _parts text[];
BEGIN
    SELECT string_to_array(name, '/') INTO _parts;
    RETURN _parts[array_length(_parts, 1)];
END
$$;

alter function filename(text) owner to supabase_storage_admin;

