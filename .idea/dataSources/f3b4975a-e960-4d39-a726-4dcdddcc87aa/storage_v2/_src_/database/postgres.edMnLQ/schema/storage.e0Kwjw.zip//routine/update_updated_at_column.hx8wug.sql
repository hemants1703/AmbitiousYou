create function update_updated_at_column() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;

alter function update_updated_at_column() owner to supabase_storage_admin;

