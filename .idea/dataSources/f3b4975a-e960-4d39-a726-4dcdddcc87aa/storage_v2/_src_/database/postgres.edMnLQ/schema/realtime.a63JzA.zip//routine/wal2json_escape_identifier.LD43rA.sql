create function wal2json_escape_identifier(name text) returns text
    immutable
    strict
    language sql
as
$$
  -- Prefix `\`, `,`, `.`, and any whitespace with `\`
  SELECT regexp_replace(name, '([\\,.[:space:]])', '\\\1', 'g')
$$;

alter function wal2json_escape_identifier(text) owner to supabase_realtime_admin;

grant execute on function wal2json_escape_identifier(text) to postgres;

grant execute on function wal2json_escape_identifier(text) to dashboard_user;

