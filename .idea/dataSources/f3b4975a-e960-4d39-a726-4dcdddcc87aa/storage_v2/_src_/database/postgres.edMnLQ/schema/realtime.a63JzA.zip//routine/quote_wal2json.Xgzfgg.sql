create function quote_wal2json(entity regclass) returns text
    immutable
    strict
    language sql
as
$$
  SELECT
    realtime.wal2json_escape_identifier(nsp.nspname::text)
    || '.'
    || realtime.wal2json_escape_identifier(pc.relname::text)
  FROM pg_class pc
  JOIN pg_namespace nsp ON pc.relnamespace = nsp.oid
  WHERE pc.oid = entity
$$;

alter function quote_wal2json(regclass) owner to supabase_realtime_admin;

grant execute on function quote_wal2json(regclass) to postgres;

grant execute on function quote_wal2json(regclass) to anon;

grant execute on function quote_wal2json(regclass) to authenticated;

grant execute on function quote_wal2json(regclass) to service_role;

grant execute on function quote_wal2json(regclass) to dashboard_user;

