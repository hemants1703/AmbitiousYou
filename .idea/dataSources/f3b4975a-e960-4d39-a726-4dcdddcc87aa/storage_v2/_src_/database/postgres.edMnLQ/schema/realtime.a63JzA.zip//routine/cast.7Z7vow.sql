create function "cast"(val text, type_ regtype) returns jsonb
    immutable
    language plpgsql
as
$$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;

alter function "cast"(text, regtype) owner to supabase_realtime_admin;

grant execute on function "cast"(text, regtype) to postgres;

grant execute on function "cast"(text, regtype) to anon;

grant execute on function "cast"(text, regtype) to authenticated;

grant execute on function "cast"(text, regtype) to service_role;

grant execute on function "cast"(text, regtype) to dashboard_user;

