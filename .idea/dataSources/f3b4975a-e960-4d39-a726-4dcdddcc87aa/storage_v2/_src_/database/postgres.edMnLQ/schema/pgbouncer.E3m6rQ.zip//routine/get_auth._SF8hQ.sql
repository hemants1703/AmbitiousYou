create function get_auth(p_usename text)
    returns TABLE(username text, password text)
    security definer
    SET search_path = ""
    language plpgsql
as
$$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $$;

alter function get_auth(text) owner to supabase_admin;

grant execute on function get_auth(text) to pgbouncer;

