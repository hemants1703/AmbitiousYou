create function graphql("operationName" text DEFAULT NULL::text, query text DEFAULT NULL::text, variables jsonb DEFAULT NULL::jsonb, extensions jsonb DEFAULT NULL::jsonb) returns jsonb
    language plpgsql
as
$$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;

alter function graphql(text, text, jsonb, jsonb) owner to supabase_admin;

grant execute on function graphql(text, text, jsonb, jsonb) to postgres;

grant execute on function graphql(text, text, jsonb, jsonb) to anon;

grant execute on function graphql(text, text, jsonb, jsonb) to authenticated;

grant execute on function graphql(text, text, jsonb, jsonb) to service_role;

