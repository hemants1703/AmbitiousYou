create function enforce_bucket_name_length() returns trigger
    language plpgsql
as
$$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;

alter function enforce_bucket_name_length() owner to supabase_storage_admin;

